#Region " About "

'|------DO-NOT-REMOVE------|

' Creator: HazelDev
' Site   : HazelDev.co.nr
' Created: 5.Mar.2012
' Changed: 13.Jul.2014
' Version: 1.1
' NET FW : 2.0 and above

'|------DO-NOT-REMOVE------|

' This component was created for user projects in which you want to put
' a limit to the amount of available colors in the ComboBox.

' See the License file, included in the same directory as this one for
' usage and distribution details.

#End Region

Class ColorComboBox
    Inherits System.Windows.Forms.ComboBox

#Region " Variables "

    Private ColorArray As String() = {"Black", "White", "DimGray", "Gray", "DarkGray", "Silver", "LightGray", "Gainsboro", "WhiteSmoke", "Maroon", "DarkRed", "Red", _
                                     "Brown", "FireBrick", "IndianRed"} ' The colors that will be added to the ComboBox control. You can add your own colors to the ComboBox using "MyCustomColors" Property (look below) from the designer.
    Private _Color As Color ' This declaration is used to retrieve the color name and value from the color array, and also used to draw the color rectangle inside the ComboBox.

#End Region

    Public Property MyCustomColors() As String()
        ' This is a control property which can be modified from the control's property panel to add your own colors to the ComboBox.
        ' By default, the colors in [ColorArray] are added. You can remove them if not desired.
        Get
            Return ColorArray
        End Get
        Set(value As String())
            Dim ValNum As Integer = value.Length
            ColorArray = New String(ValNum - 1) {}
            For i As Integer = 0 To ValNum - 1
                ColorArray(i) = value(i)
            Next
            Me.Items.Clear()
            InitializeComboBox()
        End Set
    End Property

    Private Sub InitializeComboBox()
        ' Update the control.
        If ColorArray Is Nothing Then
            Return
        End If
        For Each Item As String In ColorArray
            Try
                If Color.FromName(Item).IsKnownColor Then
                    Me.Items.Add(Item)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Exclamation, "Thrown Exception")
            End Try
        Next
    End Sub

    Public Sub New()
        ' Initialize the control once it's added to the form designer.
        InitializeComponent()
        DrawMode = DrawMode.OwnerDrawFixed
        DropDownStyle = ComboBoxStyle.DropDownList
        FlatStyle = Windows.Forms.FlatStyle.System
        BeginUpdate()
        InitializeComboBox()
        EndUpdate()
    End Sub

    Protected Overrides Sub OnDrawItem(e As DrawItemEventArgs)
        MyBase.OnDrawItem(e)
        ' Draw the selection background.
        If (e.State And DrawItemState.ComboBoxEdit) <> DrawItemState.ComboBoxEdit Then
            e.DrawBackground()
        End If

        If e.Index = -1 Then
            Return
        End If

        Dim G As Graphics = e.Graphics

        ' Get the color names of each item in the ComboBox. This is used to draw the string value in the ComboBox.
        _Color = Color.FromName(DirectCast(MyBase.Items(e.Index), String))

        ' Draw rectangle which will contain the colors of the control's ColorArray.
        G.FillRectangle(New SolidBrush(_Color), 5I, e.Bounds.Top + 2I, 25, e.Bounds.Height - 5I)
        ' Draw a border around the color rectangle. You can remove the line below if you don't want a border to be drawn.
        G.DrawRectangle(Pens.Black, 5I, e.Bounds.Top + 2I, 25, e.Bounds.Height - 5I)
        ' Draw the string value of the chosen color depending on the selected item.
        G.DrawString(_Color.Name, e.Font, New SolidBrush(ForeColor), 33, ((e.Bounds.Height - Me.Font.Height) \ 2I) + e.Bounds.Top)

        ' Me.Invalidate() --> Makes the control more interactive by creating a dynamic hover-like pre-selection. You can remove this line if not desired.
        '                 +-> However, using [Invalidate] means that the control will keep on redrawing itself. Therefore, using it on Flat and Popup styles will cause the control to flicker.
    End Sub
End Class