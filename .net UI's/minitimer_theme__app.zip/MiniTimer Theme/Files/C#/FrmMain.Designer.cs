// VBConversions Note: VB project level imports
using System.Collections.Generic;
using System;
using System.Drawing;
using System.Diagnostics;
using System.Data;
using Microsoft.VisualBasic;
using System.Collections;
using System.Windows.Forms;
// End of VB project level imports


namespace MiniTimer_Theme
{
	[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]public 
	partial class FrmMain : System.Windows.Forms.Form
	{
		
		//Form overrides dispose to clean up the component list.
		[System.Diagnostics.DebuggerNonUserCode()]protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}
		
		//Required by the Windows Form Designer
		private System.ComponentModel.Container components = null;
		
		//NOTE: The following procedure is required by the Windows Form Designer
		//It can be modified using the Windows Form Designer.
		//Do not modify it using the code editor.
		[System.Diagnostics.DebuggerStepThrough()]private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.MiniTimer_ThemeContainer1 = new MiniTimer_Theme.MiniTimer_ThemeContainer();
            this.NUD_Sec = new MiniTimer_Theme.MiniTimer_NumericUpDown();
            this.NUD_Min = new MiniTimer_Theme.MiniTimer_NumericUpDown();
            this.NUD_Hour = new MiniTimer_Theme.MiniTimer_NumericUpDown();
            this.LBL_Mode = new MiniTimer_Theme.MiniTimer_LinkLabel();
            this.LBL_Sec = new MiniTimer_Theme.MiniTimer_Label();
            this.LBL_Min = new MiniTimer_Theme.MiniTimer_Label();
            this.LBL_Hour = new MiniTimer_Theme.MiniTimer_Label();
            this.LBL_Time = new MiniTimer_Theme.MiniTimer_HeaderLabel();
            this.LBL_TotalTime = new MiniTimer_Theme.MiniTimer_Label();
            this.LBL_xTotalTime = new MiniTimer_Theme.MiniTimer_Label();
            this.MiniTimer_ControlBox = new MiniTimer_Theme.MiniTimer_ControlBox();
            this.ButtonBase = new MiniTimer_Theme.MiniTimer_ButtonBase();
            this.BTN_Reset = new MiniTimer_Theme.MiniTimer_Button_1();
            this.BTN_Start = new MiniTimer_Theme.MiniTimer_Button_1();
            this.BTN_Stop = new MiniTimer_Theme.MiniTimer_Button_1();
            this.MiniTimer_ThemeContainer1.SuspendLayout();
            this.ButtonBase.SuspendLayout();
            this.SuspendLayout();
            // 
            // MiniTimer_ThemeContainer1
            // 
            this.MiniTimer_ThemeContainer1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.MiniTimer_ThemeContainer1.Controls.Add(this.NUD_Sec);
            this.MiniTimer_ThemeContainer1.Controls.Add(this.NUD_Min);
            this.MiniTimer_ThemeContainer1.Controls.Add(this.NUD_Hour);
            this.MiniTimer_ThemeContainer1.Controls.Add(this.LBL_Mode);
            this.MiniTimer_ThemeContainer1.Controls.Add(this.LBL_Sec);
            this.MiniTimer_ThemeContainer1.Controls.Add(this.LBL_Min);
            this.MiniTimer_ThemeContainer1.Controls.Add(this.LBL_Hour);
            this.MiniTimer_ThemeContainer1.Controls.Add(this.LBL_Time);
            this.MiniTimer_ThemeContainer1.Controls.Add(this.LBL_TotalTime);
            this.MiniTimer_ThemeContainer1.Controls.Add(this.LBL_xTotalTime);
            this.MiniTimer_ThemeContainer1.Controls.Add(this.MiniTimer_ControlBox);
            this.MiniTimer_ThemeContainer1.Controls.Add(this.ButtonBase);
            this.MiniTimer_ThemeContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MiniTimer_ThemeContainer1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.MiniTimer_ThemeContainer1.Location = new System.Drawing.Point(0, 0);
            this.MiniTimer_ThemeContainer1.Name = "MiniTimer_ThemeContainer1";
            this.MiniTimer_ThemeContainer1.Padding = new System.Windows.Forms.Padding(20, 56, 20, 16);
            this.MiniTimer_ThemeContainer1.Sizable = false;
            this.MiniTimer_ThemeContainer1.Size = new System.Drawing.Size(321, 172);
            this.MiniTimer_ThemeContainer1.SmartBounds = true;
            this.MiniTimer_ThemeContainer1.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.MiniTimer_ThemeContainer1.TabIndex = 0;
            this.MiniTimer_ThemeContainer1.Text = "Mini Timer";
            // 
            // NUD_Sec
            // 
            this.NUD_Sec.BackColor = System.Drawing.Color.White;
            this.NUD_Sec.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.NUD_Sec.ForeColor = System.Drawing.Color.Black;
            this.NUD_Sec.Location = new System.Drawing.Point(275, 98);
            this.NUD_Sec.Maximum = ((long)(59));
            this.NUD_Sec.Minimum = ((long)(0));
            this.NUD_Sec.Name = "NUD_Sec";
            this.NUD_Sec.Size = new System.Drawing.Size(39, 27);
            this.NUD_Sec.TabIndex = 27;
            this.NUD_Sec.Text = "HazelDev_NumericUpDown3";
            this.NUD_Sec.Value = ((long)(0));
            // 
            // NUD_Min
            // 
            this.NUD_Min.BackColor = System.Drawing.Color.White;
            this.NUD_Min.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.NUD_Min.ForeColor = System.Drawing.Color.Black;
            this.NUD_Min.Location = new System.Drawing.Point(226, 98);
            this.NUD_Min.Maximum = ((long)(59));
            this.NUD_Min.Minimum = ((long)(0));
            this.NUD_Min.Name = "NUD_Min";
            this.NUD_Min.Size = new System.Drawing.Size(39, 27);
            this.NUD_Min.TabIndex = 26;
            this.NUD_Min.Text = "HazelDev_NumericUpDown2";
            this.NUD_Min.Value = ((long)(0));
            // 
            // NUD_Hour
            // 
            this.NUD_Hour.BackColor = System.Drawing.Color.White;
            this.NUD_Hour.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.NUD_Hour.ForeColor = System.Drawing.Color.Black;
            this.NUD_Hour.Location = new System.Drawing.Point(175, 98);
            this.NUD_Hour.Maximum = ((long)(23));
            this.NUD_Hour.Minimum = ((long)(0));
            this.NUD_Hour.Name = "NUD_Hour";
            this.NUD_Hour.Size = new System.Drawing.Size(39, 27);
            this.NUD_Hour.TabIndex = 25;
            this.NUD_Hour.Text = "HazelDev_NumericUpDown1";
            this.NUD_Hour.Value = ((long)(0));
            // 
            // LBL_Mode
            // 
            this.LBL_Mode.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(134)))), ((int)(((byte)(158)))));
            this.LBL_Mode.AutoSize = true;
            this.LBL_Mode.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Mode.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.LBL_Mode.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LBL_Mode.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(151)))), ((int)(((byte)(172)))));
            this.LBL_Mode.Location = new System.Drawing.Point(61, 13);
            this.LBL_Mode.Name = "LBL_Mode";
            this.LBL_Mode.Size = new System.Drawing.Size(68, 16);
            this.LBL_Mode.TabIndex = 24;
            this.LBL_Mode.TabStop = true;
            this.LBL_Mode.Text = "Stopwatch";
            this.LBL_Mode.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(151)))), ((int)(((byte)(172)))));
            this.LBL_Mode.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LBL_Mode_LinkClicked);
            // 
            // LBL_Sec
            // 
            this.LBL_Sec.AutoSize = true;
            this.LBL_Sec.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Sec.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Sec.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.LBL_Sec.Location = new System.Drawing.Point(281, 84);
            this.LBL_Sec.Name = "LBL_Sec";
            this.LBL_Sec.Size = new System.Drawing.Size(24, 11);
            this.LBL_Sec.TabIndex = 12;
            this.LBL_Sec.Text = "SEC";
            // 
            // LBL_Min
            // 
            this.LBL_Min.AutoSize = true;
            this.LBL_Min.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Min.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Min.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.LBL_Min.Location = new System.Drawing.Point(231, 84);
            this.LBL_Min.Name = "LBL_Min";
            this.LBL_Min.Size = new System.Drawing.Size(24, 11);
            this.LBL_Min.TabIndex = 11;
            this.LBL_Min.Text = "MIN";
            // 
            // LBL_Hour
            // 
            this.LBL_Hour.AutoSize = true;
            this.LBL_Hour.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Hour.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Hour.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.LBL_Hour.Location = new System.Drawing.Point(178, 84);
            this.LBL_Hour.Name = "LBL_Hour";
            this.LBL_Hour.Size = new System.Drawing.Size(33, 11);
            this.LBL_Hour.TabIndex = 10;
            this.LBL_Hour.Text = "HOUR";
            // 
            // LBL_Time
            // 
            this.LBL_Time.AutoSize = true;
            this.LBL_Time.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Time.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Time.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(103)))), ((int)(((byte)(103)))));
            this.LBL_Time.Location = new System.Drawing.Point(171, 47);
            this.LBL_Time.Name = "LBL_Time";
            this.LBL_Time.Size = new System.Drawing.Size(147, 37);
            this.LBL_Time.TabIndex = 9;
            this.LBL_Time.Text = "00 : 00 : 00";
            // 
            // LBL_TotalTime
            // 
            this.LBL_TotalTime.AutoSize = true;
            this.LBL_TotalTime.BackColor = System.Drawing.Color.Transparent;
            this.LBL_TotalTime.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_TotalTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.LBL_TotalTime.Location = new System.Drawing.Point(249, 141);
            this.LBL_TotalTime.Name = "LBL_TotalTime";
            this.LBL_TotalTime.Size = new System.Drawing.Size(60, 16);
            this.LBL_TotalTime.TabIndex = 4;
            this.LBL_TotalTime.Text = "00:00:00";
            // 
            // LBL_xTotalTime
            // 
            this.LBL_xTotalTime.AutoSize = true;
            this.LBL_xTotalTime.BackColor = System.Drawing.Color.Transparent;
            this.LBL_xTotalTime.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_xTotalTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            this.LBL_xTotalTime.Location = new System.Drawing.Point(12, 141);
            this.LBL_xTotalTime.Name = "LBL_xTotalTime";
            this.LBL_xTotalTime.Size = new System.Drawing.Size(66, 16);
            this.LBL_xTotalTime.TabIndex = 2;
            this.LBL_xTotalTime.Text = "Total time";
            // 
            // MiniTimer_ControlBox
            // 
            this.MiniTimer_ControlBox.BackColor = System.Drawing.Color.Transparent;
            this.MiniTimer_ControlBox.EnableMaximize = false;
            this.MiniTimer_ControlBox.Font = new System.Drawing.Font("Marlett", 7F);
            this.MiniTimer_ControlBox.Location = new System.Drawing.Point(15, 13);
            this.MiniTimer_ControlBox.Name = "MiniTimer_ControlBox";
            this.MiniTimer_ControlBox.Size = new System.Drawing.Size(40, 16);
            this.MiniTimer_ControlBox.TabIndex = 0;
            this.MiniTimer_ControlBox.Text = "MiniTimer_ControlBox1";
            // 
            // ButtonBase
            // 
            this.ButtonBase.Controls.Add(this.BTN_Reset);
            this.ButtonBase.Controls.Add(this.BTN_Start);
            this.ButtonBase.Controls.Add(this.BTN_Stop);
            this.ButtonBase.Location = new System.Drawing.Point(15, 63);
            this.ButtonBase.Name = "ButtonBase";
            this.ButtonBase.Size = new System.Drawing.Size(116, 46);
            this.ButtonBase.TabIndex = 17;
            this.ButtonBase.Text = "MiniTimer_ButtonBase1";
            // 
            // BTN_Reset
            // 
            this.BTN_Reset.BackColor = System.Drawing.Color.Transparent;
            this.BTN_Reset.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.BTN_Reset.Image = ((System.Drawing.Image)(resources.GetObject("BTN_Reset.Image")));
            this.BTN_Reset.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BTN_Reset.Location = new System.Drawing.Point(79, 9);
            this.BTN_Reset.Name = "BTN_Reset";
            this.BTN_Reset.Size = new System.Drawing.Size(27, 27);
            this.BTN_Reset.TabIndex = 16;
            this.BTN_Reset.Click += new System.EventHandler(this.BTN_Reset_Click);
            // 
            // BTN_Start
            // 
            this.BTN_Start.BackColor = System.Drawing.Color.Transparent;
            this.BTN_Start.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.BTN_Start.Image = ((System.Drawing.Image)(resources.GetObject("BTN_Start.Image")));
            this.BTN_Start.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BTN_Start.Location = new System.Drawing.Point(9, 9);
            this.BTN_Start.Name = "BTN_Start";
            this.BTN_Start.Size = new System.Drawing.Size(27, 27);
            this.BTN_Start.TabIndex = 15;
            this.BTN_Start.Click += new System.EventHandler(this.BTN_Start_Click);
            // 
            // BTN_Stop
            // 
            this.BTN_Stop.BackColor = System.Drawing.Color.Transparent;
            this.BTN_Stop.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.BTN_Stop.Image = ((System.Drawing.Image)(resources.GetObject("BTN_Stop.Image")));
            this.BTN_Stop.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BTN_Stop.Location = new System.Drawing.Point(44, 9);
            this.BTN_Stop.Name = "BTN_Stop";
            this.BTN_Stop.Size = new System.Drawing.Size(27, 27);
            this.BTN_Stop.TabIndex = 14;
            this.BTN_Stop.Click += new System.EventHandler(this.BTN_Stop_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(321, 172);
            this.Controls.Add(this.MiniTimer_ThemeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(321, 172);
            this.Name = "FrmMain";
            this.Opacity = 0D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mini Timer";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.MiniTimer_ThemeContainer1.ResumeLayout(false);
            this.MiniTimer_ThemeContainer1.PerformLayout();
            this.ButtonBase.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		internal MiniTimer_Theme.MiniTimer_ThemeContainer MiniTimer_ThemeContainer1;
		internal MiniTimer_Theme.MiniTimer_ControlBox MiniTimer_ControlBox;
		internal MiniTimer_Theme.MiniTimer_Label LBL_xTotalTime;
		internal MiniTimer_Theme.MiniTimer_Label LBL_TotalTime;
		internal MiniTimer_Theme.MiniTimer_Label LBL_Sec;
		internal MiniTimer_Theme.MiniTimer_Label LBL_Min;
		internal MiniTimer_Theme.MiniTimer_Label LBL_Hour;
		internal MiniTimer_Theme.MiniTimer_HeaderLabel LBL_Time;
		internal MiniTimer_Theme.MiniTimer_Button_1 BTN_Stop;
		internal MiniTimer_Theme.MiniTimer_Button_1 BTN_Reset;
		internal MiniTimer_Theme.MiniTimer_Button_1 BTN_Start;
		internal MiniTimer_Theme.MiniTimer_ButtonBase ButtonBase;
		internal MiniTimer_Theme.MiniTimer_LinkLabel LBL_Mode;
		internal MiniTimer_Theme.MiniTimer_NumericUpDown NUD_Hour;
		internal MiniTimer_Theme.MiniTimer_NumericUpDown NUD_Sec;
		internal MiniTimer_Theme.MiniTimer_NumericUpDown NUD_Min;
		
	}
	
}
