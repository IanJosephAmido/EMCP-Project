using System.Collections.Generic;
using System;
using System.Data;
using Microsoft.VisualBasic;
using System.Collections;
using System.Windows.Forms;

namespace MiniTimer_Theme
{
	public partial class FrmMain
	{
		
#region Default Instance
		
		private static FrmMain defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
public static FrmMain Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new FrmMain();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		
		const int CS_DROPSHADOW = 0x20000;
		internal Timer Opacity1 = new Timer();
		internal Timer Opacity2 = new Timer();
		internal Timer CountdownTimer = new Timer();
		private TimeSpan MyTimeSpan = new TimeSpan();
		private System.Diagnostics.Stopwatch MyStopWatch = new System.Diagnostics.Stopwatch();
		
#region  Initializer
		
		public FrmMain()
		{
			InitializeComponent();
			
			//Added to support default instance behavour in C#
			if (defaultInstance == null)
				defaultInstance = this;
			
			Opacity1.Enabled = true;
			Opacity1.Interval = 1;
			Opacity2.Enabled = false;
			Opacity2.Interval = 1;
			
			CountdownTimer.Enabled = false;
			CountdownTimer.Interval = 1000;
			
			Opacity1.Tick += Opacity1_Tick;
			Opacity2.Tick += Opacity2_Tick;
			CountdownTimer.Tick += CountdownTimer_Tick;
		}
		
#endregion
#region  Opacity1 & Opacity2
		
		private void Opacity1_Tick(object sender, EventArgs e)
		{
			Opacity += 0.03;
			if (Opacity == 100)
			{
				Opacity2.Enabled = false;
			}
		}
		
		private void Opacity2_Tick(object sender, EventArgs e)
		{
			Opacity -= 0.03;
			if (Opacity == 0)
			{
				this.Close();
			}
		}
		
#endregion
		
protected override CreateParams CreateParams
		{
			get
			{
				CreateParams parameters = base.CreateParams;
				if (OSFeature.IsPresent(SystemParameter.DropShadow))
				{
					parameters.ClassStyle = parameters.ClassStyle | CS_DROPSHADOW;
				}
				return parameters;
			}
		}
		
		private void CountdownTimer_Tick(object sender, EventArgs e)
		{
			if (LBL_Mode.Text == "Stopwatch")
			{
				if (MyTimeSpan.TotalSeconds > 0)
				{
					MyTimeSpan = MyTimeSpan.Subtract(new TimeSpan(0, 0, 1));
					LBL_Time.Text = System.Convert.ToString(string.Format("{0} : {1} : {2}", MyTimeSpan.Hours < 10 ? (object) ("0" + System.Convert.ToString(MyTimeSpan.Hours)) : MyTimeSpan.Hours, MyTimeSpan.Minutes < 10 ? (object) ("0" + System.Convert.ToString(MyTimeSpan.Minutes)) : MyTimeSpan.Minutes, MyTimeSpan.Seconds < 10 ? (object) ("0" + System.Convert.ToString(MyTimeSpan.Seconds)) : MyTimeSpan.Seconds));
					this.Refresh();
				}
				else
				{
					CountdownTimer.Enabled = false;
					try
					{
						(new Microsoft.VisualBasic.Devices.Audio()).Play(Application.StartupPath + "\\Beep.wav", AudioPlayMode.Background);
					}
					catch (Exception)
					{
						Interaction.MsgBox("The file \'Beep.wav\' was not found", MsgBoxStyle.Critical, null);
					}
				}
			}
			else if (LBL_Mode.Text == "Countdown")
			{
				TimeSpan elapsed = this.MyStopWatch.Elapsed;
				LBL_Time.Text = string.Format("{0:00} : {1:00} : {2:00}", 
					Math.Floor(elapsed.TotalHours), 
					elapsed.Minutes, elapsed.Seconds);
			}
			
		}
		
		public void BTN_Start_Click(object sender, EventArgs e)
		{
			if (LBL_Mode.Text == "Stopwatch")
			{
				if (LBL_Time.Text == "00 : 00 : 00" == true)
				{
					MyTimeSpan = new TimeSpan((int) NUD_Hour.Value, (int) NUD_Min.Value, (int) NUD_Sec.Value);
					CountdownTimer.Enabled = true;
					LBL_TotalTime.Text = MyTimeSpan.ToString();
				}
				else
				{
					CountdownTimer.Enabled = true;
				}
			}
			else if (LBL_Mode.Text == "Countdown")
			{
				CountdownTimer.Enabled = true;
				MyStopWatch.Start();
			}
		}
		
		public void BTN_Stop_Click(object sender, EventArgs e)
		{
			if (LBL_Mode.Text == "Stopwatch")
			{
				CountdownTimer.Stop();
			}
			else if (LBL_Mode.Text == "Countdown")
			{
				MyStopWatch.Stop();
			}
		}
		
		public void BTN_Reset_Click(object sender, EventArgs e)
		{
			if (LBL_Mode.Text == "Stopwatch")
			{
				CountdownTimer.Enabled = false;
				LBL_Time.Text = "00 : 00 : 00";
				LBL_TotalTime.Text = "00:00:00";
				MyTimeSpan = new TimeSpan((int) NUD_Hour.Value, (int) NUD_Min.Value, (int) NUD_Sec.Value);
			}
			else if (LBL_Mode.Text == "Countdown")
			{
				MyStopWatch.Reset();
				LBL_Time.Text = "00 : 00 : 00";
			}
		}
		
		public void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
		{
			Opacity1.Tick -= Opacity1_Tick;
			Opacity2.Tick -= Opacity2_Tick;
			CountdownTimer.Tick -= CountdownTimer_Tick;
		}
		
		public void LBL_Mode_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			if (LBL_Mode.Text == "Stopwatch")
			{
				LBL_Mode.Text = "Countdown";
				NUD_Hour.Enabled = false;
				NUD_Min.Enabled = false;
				NUD_Sec.Enabled = false;
			}
			else if (LBL_Mode.Text == "Countdown")
			{
				LBL_Mode.Text = "Stopwatch";
				NUD_Hour.Enabled = true;
				NUD_Min.Enabled = true;
				NUD_Sec.Enabled = true;
			}
		}

        private void BTN_Start_Click_1(object sender, EventArgs e)
        {

        }
	}
	
}
