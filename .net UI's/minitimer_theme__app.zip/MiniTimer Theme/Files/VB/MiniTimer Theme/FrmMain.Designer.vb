﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMain))
        Me.MiniTimer_ThemeContainer1 = New MiniTimer_Theme.MiniTimer_ThemeContainer()
        Me.NUD_Sec = New MiniTimer_Theme.MiniTimer_NumericUpDown()
        Me.NUD_Min = New MiniTimer_Theme.MiniTimer_NumericUpDown()
        Me.NUD_Hour = New MiniTimer_Theme.MiniTimer_NumericUpDown()
        Me.LBL_Mode = New MiniTimer_Theme.MiniTimer_LinkLabel()
        Me.LBL_Sec = New MiniTimer_Theme.MiniTimer_Label()
        Me.LBL_Min = New MiniTimer_Theme.MiniTimer_Label()
        Me.LBL_Hour = New MiniTimer_Theme.MiniTimer_Label()
        Me.LBL_Time = New MiniTimer_Theme.MiniTimer_HeaderLabel()
        Me.LBL_TotalTime = New MiniTimer_Theme.MiniTimer_Label()
        Me.LBL_xTotalTime = New MiniTimer_Theme.MiniTimer_Label()
        Me.MiniTimer_ControlBox = New MiniTimer_Theme.MiniTimer_ControlBox()
        Me.ButtonBase = New MiniTimer_Theme.MiniTimer_ButtonBase()
        Me.BTN_Reset = New MiniTimer_Theme.MiniTimer_Button_1()
        Me.BTN_Start = New MiniTimer_Theme.MiniTimer_Button_1()
        Me.BTN_Stop = New MiniTimer_Theme.MiniTimer_Button_1()
        Me.MiniTimer_ThemeContainer1.SuspendLayout()
        Me.ButtonBase.SuspendLayout()
        Me.SuspendLayout()
        '
        'MiniTimer_ThemeContainer1
        '
        Me.MiniTimer_ThemeContainer1.BackColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(243, Byte), Integer))
        Me.MiniTimer_ThemeContainer1.Controls.Add(Me.NUD_Sec)
        Me.MiniTimer_ThemeContainer1.Controls.Add(Me.NUD_Min)
        Me.MiniTimer_ThemeContainer1.Controls.Add(Me.NUD_Hour)
        Me.MiniTimer_ThemeContainer1.Controls.Add(Me.LBL_Mode)
        Me.MiniTimer_ThemeContainer1.Controls.Add(Me.LBL_Sec)
        Me.MiniTimer_ThemeContainer1.Controls.Add(Me.LBL_Min)
        Me.MiniTimer_ThemeContainer1.Controls.Add(Me.LBL_Hour)
        Me.MiniTimer_ThemeContainer1.Controls.Add(Me.LBL_Time)
        Me.MiniTimer_ThemeContainer1.Controls.Add(Me.LBL_TotalTime)
        Me.MiniTimer_ThemeContainer1.Controls.Add(Me.LBL_xTotalTime)
        Me.MiniTimer_ThemeContainer1.Controls.Add(Me.MiniTimer_ControlBox)
        Me.MiniTimer_ThemeContainer1.Controls.Add(Me.ButtonBase)
        Me.MiniTimer_ThemeContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MiniTimer_ThemeContainer1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.MiniTimer_ThemeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.MiniTimer_ThemeContainer1.Name = "MiniTimer_ThemeContainer1"
        Me.MiniTimer_ThemeContainer1.Padding = New System.Windows.Forms.Padding(20, 56, 20, 16)
        Me.MiniTimer_ThemeContainer1.RoundCorners = False
        Me.MiniTimer_ThemeContainer1.Sizable = False
        Me.MiniTimer_ThemeContainer1.Size = New System.Drawing.Size(321, 172)
        Me.MiniTimer_ThemeContainer1.SmartBounds = True
        Me.MiniTimer_ThemeContainer1.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.MiniTimer_ThemeContainer1.TabIndex = 0
        Me.MiniTimer_ThemeContainer1.Text = "Mini Timer"
        '
        'NUD_Sec
        '
        Me.NUD_Sec.BackColor = System.Drawing.Color.White
        Me.NUD_Sec.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.NUD_Sec.ForeColor = System.Drawing.Color.Black
        Me.NUD_Sec.Location = New System.Drawing.Point(275, 98)
        Me.NUD_Sec.Maximum = CType(59, Long)
        Me.NUD_Sec.Minimum = CType(0, Long)
        Me.NUD_Sec.Name = "NUD_Sec"
        Me.NUD_Sec.Size = New System.Drawing.Size(39, 27)
        Me.NUD_Sec.TabIndex = 27
        Me.NUD_Sec.Text = "HazelDev_NumericUpDown3"
        Me.NUD_Sec.Value = CType(0, Long)
        '
        'NUD_Min
        '
        Me.NUD_Min.BackColor = System.Drawing.Color.White
        Me.NUD_Min.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.NUD_Min.ForeColor = System.Drawing.Color.Black
        Me.NUD_Min.Location = New System.Drawing.Point(226, 98)
        Me.NUD_Min.Maximum = CType(59, Long)
        Me.NUD_Min.Minimum = CType(0, Long)
        Me.NUD_Min.Name = "NUD_Min"
        Me.NUD_Min.Size = New System.Drawing.Size(39, 27)
        Me.NUD_Min.TabIndex = 26
        Me.NUD_Min.Text = "HazelDev_NumericUpDown2"
        Me.NUD_Min.Value = CType(0, Long)
        '
        'NUD_Hour
        '
        Me.NUD_Hour.BackColor = System.Drawing.Color.White
        Me.NUD_Hour.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.NUD_Hour.ForeColor = System.Drawing.Color.Black
        Me.NUD_Hour.Location = New System.Drawing.Point(175, 98)
        Me.NUD_Hour.Maximum = CType(23, Long)
        Me.NUD_Hour.Minimum = CType(0, Long)
        Me.NUD_Hour.Name = "NUD_Hour"
        Me.NUD_Hour.Size = New System.Drawing.Size(39, 27)
        Me.NUD_Hour.TabIndex = 25
        Me.NUD_Hour.Text = "HazelDev_NumericUpDown1"
        Me.NUD_Hour.Value = CType(0, Long)
        '
        'LBL_Mode
        '
        Me.LBL_Mode.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(134, Byte), Integer), CType(CType(158, Byte), Integer))
        Me.LBL_Mode.AutoSize = True
        Me.LBL_Mode.BackColor = System.Drawing.Color.Transparent
        Me.LBL_Mode.Font = New System.Drawing.Font("Tahoma", 9.75!)
        Me.LBL_Mode.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LBL_Mode.LinkColor = System.Drawing.Color.FromArgb(CType(CType(129, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(172, Byte), Integer))
        Me.LBL_Mode.Location = New System.Drawing.Point(61, 13)
        Me.LBL_Mode.Name = "LBL_Mode"
        Me.LBL_Mode.Size = New System.Drawing.Size(68, 16)
        Me.LBL_Mode.TabIndex = 24
        Me.LBL_Mode.TabStop = True
        Me.LBL_Mode.Text = "Stopwatch"
        Me.LBL_Mode.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(129, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(172, Byte), Integer))
        '
        'LBL_Sec
        '
        Me.LBL_Sec.AutoSize = True
        Me.LBL_Sec.BackColor = System.Drawing.Color.Transparent
        Me.LBL_Sec.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBL_Sec.ForeColor = System.Drawing.Color.FromArgb(CType(CType(136, Byte), Integer), CType(CType(136, Byte), Integer), CType(CType(136, Byte), Integer))
        Me.LBL_Sec.Location = New System.Drawing.Point(281, 84)
        Me.LBL_Sec.Name = "LBL_Sec"
        Me.LBL_Sec.Size = New System.Drawing.Size(24, 11)
        Me.LBL_Sec.TabIndex = 12
        Me.LBL_Sec.Text = "SEC"
        '
        'LBL_Min
        '
        Me.LBL_Min.AutoSize = True
        Me.LBL_Min.BackColor = System.Drawing.Color.Transparent
        Me.LBL_Min.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBL_Min.ForeColor = System.Drawing.Color.FromArgb(CType(CType(136, Byte), Integer), CType(CType(136, Byte), Integer), CType(CType(136, Byte), Integer))
        Me.LBL_Min.Location = New System.Drawing.Point(231, 84)
        Me.LBL_Min.Name = "LBL_Min"
        Me.LBL_Min.Size = New System.Drawing.Size(24, 11)
        Me.LBL_Min.TabIndex = 11
        Me.LBL_Min.Text = "MIN"
        '
        'LBL_Hour
        '
        Me.LBL_Hour.AutoSize = True
        Me.LBL_Hour.BackColor = System.Drawing.Color.Transparent
        Me.LBL_Hour.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBL_Hour.ForeColor = System.Drawing.Color.FromArgb(CType(CType(136, Byte), Integer), CType(CType(136, Byte), Integer), CType(CType(136, Byte), Integer))
        Me.LBL_Hour.Location = New System.Drawing.Point(178, 84)
        Me.LBL_Hour.Name = "LBL_Hour"
        Me.LBL_Hour.Size = New System.Drawing.Size(33, 11)
        Me.LBL_Hour.TabIndex = 10
        Me.LBL_Hour.Text = "HOUR"
        '
        'LBL_Time
        '
        Me.LBL_Time.AutoSize = True
        Me.LBL_Time.BackColor = System.Drawing.Color.Transparent
        Me.LBL_Time.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBL_Time.ForeColor = System.Drawing.Color.FromArgb(CType(CType(103, Byte), Integer), CType(CType(103, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.LBL_Time.Location = New System.Drawing.Point(171, 47)
        Me.LBL_Time.Name = "LBL_Time"
        Me.LBL_Time.Size = New System.Drawing.Size(147, 37)
        Me.LBL_Time.TabIndex = 9
        Me.LBL_Time.Text = "00 : 00 : 00"
        '
        'LBL_TotalTime
        '
        Me.LBL_TotalTime.AutoSize = True
        Me.LBL_TotalTime.BackColor = System.Drawing.Color.Transparent
        Me.LBL_TotalTime.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBL_TotalTime.ForeColor = System.Drawing.Color.FromArgb(CType(CType(136, Byte), Integer), CType(CType(136, Byte), Integer), CType(CType(136, Byte), Integer))
        Me.LBL_TotalTime.Location = New System.Drawing.Point(249, 141)
        Me.LBL_TotalTime.Name = "LBL_TotalTime"
        Me.LBL_TotalTime.Size = New System.Drawing.Size(60, 16)
        Me.LBL_TotalTime.TabIndex = 4
        Me.LBL_TotalTime.Text = "00:00:00"
        '
        'LBL_xTotalTime
        '
        Me.LBL_xTotalTime.AutoSize = True
        Me.LBL_xTotalTime.BackColor = System.Drawing.Color.Transparent
        Me.LBL_xTotalTime.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBL_xTotalTime.ForeColor = System.Drawing.Color.FromArgb(CType(CType(136, Byte), Integer), CType(CType(136, Byte), Integer), CType(CType(136, Byte), Integer))
        Me.LBL_xTotalTime.Location = New System.Drawing.Point(12, 141)
        Me.LBL_xTotalTime.Name = "LBL_xTotalTime"
        Me.LBL_xTotalTime.Size = New System.Drawing.Size(66, 16)
        Me.LBL_xTotalTime.TabIndex = 2
        Me.LBL_xTotalTime.Text = "Total time"
        '
        'MiniTimer_ControlBox
        '
        Me.MiniTimer_ControlBox.BackColor = System.Drawing.Color.Transparent
        Me.MiniTimer_ControlBox.EnableMaximize = False
        Me.MiniTimer_ControlBox.Font = New System.Drawing.Font("Marlett", 7.0!)
        Me.MiniTimer_ControlBox.Location = New System.Drawing.Point(15, 13)
        Me.MiniTimer_ControlBox.Name = "MiniTimer_ControlBox"
        Me.MiniTimer_ControlBox.Size = New System.Drawing.Size(40, 16)
        Me.MiniTimer_ControlBox.TabIndex = 0
        Me.MiniTimer_ControlBox.Text = "MiniTimer_ControlBox1"
        '
        'ButtonBase
        '
        Me.ButtonBase.Controls.Add(Me.BTN_Reset)
        Me.ButtonBase.Controls.Add(Me.BTN_Start)
        Me.ButtonBase.Controls.Add(Me.BTN_Stop)
        Me.ButtonBase.Location = New System.Drawing.Point(15, 63)
        Me.ButtonBase.Name = "ButtonBase"
        Me.ButtonBase.Size = New System.Drawing.Size(116, 46)
        Me.ButtonBase.TabIndex = 17
        Me.ButtonBase.Text = "MiniTimer_ButtonBase1"
        '
        'BTN_Reset
        '
        Me.BTN_Reset.BackColor = System.Drawing.Color.Transparent
        Me.BTN_Reset.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.BTN_Reset.Image = CType(resources.GetObject("BTN_Reset.Image"), System.Drawing.Image)
        Me.BTN_Reset.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BTN_Reset.Location = New System.Drawing.Point(79, 9)
        Me.BTN_Reset.Name = "BTN_Reset"
        Me.BTN_Reset.Size = New System.Drawing.Size(27, 27)
        Me.BTN_Reset.TabIndex = 16
        '
        'BTN_Start
        '
        Me.BTN_Start.BackColor = System.Drawing.Color.Transparent
        Me.BTN_Start.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.BTN_Start.Image = CType(resources.GetObject("BTN_Start.Image"), System.Drawing.Image)
        Me.BTN_Start.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BTN_Start.Location = New System.Drawing.Point(9, 9)
        Me.BTN_Start.Name = "BTN_Start"
        Me.BTN_Start.Size = New System.Drawing.Size(27, 27)
        Me.BTN_Start.TabIndex = 15
        '
        'BTN_Stop
        '
        Me.BTN_Stop.BackColor = System.Drawing.Color.Transparent
        Me.BTN_Stop.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.BTN_Stop.Image = CType(resources.GetObject("BTN_Stop.Image"), System.Drawing.Image)
        Me.BTN_Stop.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BTN_Stop.Location = New System.Drawing.Point(44, 9)
        Me.BTN_Stop.Name = "BTN_Stop"
        Me.BTN_Stop.Size = New System.Drawing.Size(27, 27)
        Me.BTN_Stop.TabIndex = 14
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(321, 172)
        Me.Controls.Add(Me.MiniTimer_ThemeContainer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(321, 172)
        Me.Name = "FrmMain"
        Me.Opacity = 0.0R
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Mini Timer"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.MiniTimer_ThemeContainer1.ResumeLayout(False)
        Me.MiniTimer_ThemeContainer1.PerformLayout()
        Me.ButtonBase.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MiniTimer_ThemeContainer1 As MiniTimer_Theme.MiniTimer_ThemeContainer
    Friend WithEvents MiniTimer_ControlBox As MiniTimer_Theme.MiniTimer_ControlBox
    Friend WithEvents LBL_xTotalTime As MiniTimer_Theme.MiniTimer_Label
    Friend WithEvents LBL_TotalTime As MiniTimer_Theme.MiniTimer_Label
    Friend WithEvents LBL_Sec As MiniTimer_Theme.MiniTimer_Label
    Friend WithEvents LBL_Min As MiniTimer_Theme.MiniTimer_Label
    Friend WithEvents LBL_Hour As MiniTimer_Theme.MiniTimer_Label
    Friend WithEvents LBL_Time As MiniTimer_Theme.MiniTimer_HeaderLabel
    Friend WithEvents BTN_Stop As MiniTimer_Theme.MiniTimer_Button_1
    Friend WithEvents BTN_Reset As MiniTimer_Theme.MiniTimer_Button_1
    Friend WithEvents BTN_Start As MiniTimer_Theme.MiniTimer_Button_1
    Friend WithEvents ButtonBase As MiniTimer_Theme.MiniTimer_ButtonBase
    Friend WithEvents LBL_Mode As MiniTimer_Theme.MiniTimer_LinkLabel
    Friend WithEvents NUD_Hour As MiniTimer_Theme.MiniTimer_NumericUpDown
    Friend WithEvents NUD_Sec As MiniTimer_Theme.MiniTimer_NumericUpDown
    Friend WithEvents NUD_Min As MiniTimer_Theme.MiniTimer_NumericUpDown

End Class
