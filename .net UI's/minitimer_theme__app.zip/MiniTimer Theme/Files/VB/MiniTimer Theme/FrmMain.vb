﻿Public Class FrmMain

    Const CS_DROPSHADOW As Integer = &H20000
    Friend WithEvents Opacity1 As New Timer
    Friend WithEvents Opacity2 As New Timer
    Friend WithEvents CountdownTimer As New Timer
    Private MyTimeSpan As New TimeSpan()
    Private MyStopWatch As New Diagnostics.Stopwatch

#Region " Initializer "

    Sub New()
        InitializeComponent()

        Opacity1.Enabled = True
        Opacity1.Interval = 1
        Opacity2.Enabled = False
        Opacity2.Interval = 1

        CountdownTimer.Enabled = False
        CountdownTimer.Interval = 1000

        AddHandler Opacity1.Tick, AddressOf Opacity1_Tick
        AddHandler Opacity2.Tick, AddressOf Opacity2_Tick
        AddHandler CountdownTimer.Tick, AddressOf CountdownTimer_Tick
    End Sub

#End Region
#Region " Opacity1 & Opacity2 "

    Private Sub Opacity1_Tick(sender As Object, e As EventArgs)
        Opacity += 0.03
        If Opacity = 100 Then
            Opacity2.Enabled = False
        End If
    End Sub

    Private Sub Opacity2_Tick(sender As Object, e As EventArgs)
        Opacity -= 0.03
        If Opacity = 0 Then
            Me.Close()
        End If
    End Sub

#End Region

    Protected Overrides ReadOnly Property CreateParams() As CreateParams
        Get
            Dim parameters As CreateParams = MyBase.CreateParams
            If OSFeature.IsPresent(SystemParameter.DropShadow) Then
                parameters.ClassStyle = parameters.ClassStyle Or CS_DROPSHADOW
            End If
            Return parameters
        End Get
    End Property

    Private Sub CountdownTimer_Tick(sender As Object, e As EventArgs)
        If LBL_Mode.Text = "Stopwatch" Then
            If MyTimeSpan.TotalSeconds > 0 Then
                MyTimeSpan = MyTimeSpan.Subtract(New TimeSpan(0, 0, 1))
                LBL_Time.Text = String.Format("{0} : {1} : {2}", _
                IIf(MyTimeSpan.Hours < 10, "0" & MyTimeSpan.Hours, MyTimeSpan.Hours), _
                IIf(MyTimeSpan.Minutes < 10, "0" & MyTimeSpan.Minutes, MyTimeSpan.Minutes), _
                  IIf(MyTimeSpan.Seconds < 10, "0" & MyTimeSpan.Seconds, MyTimeSpan.Seconds))
                Me.Refresh()
            Else
                CountdownTimer.Enabled = False
                Try
                    My.Computer.Audio.Play(Application.StartupPath & "\Beep.wav", AudioPlayMode.Background)
                Catch ex As Exception
                    MsgBox("The file 'Beep.wav' was not found", MsgBoxStyle.Critical)
                End Try
            End If
        ElseIf LBL_Mode.Text = "Countdown" Then
            Dim elapsed As TimeSpan = Me.MyStopWatch.Elapsed
            LBL_Time.Text = String.Format("{0:00} : {1:00} : {2:00}", _
                                          Math.Floor(elapsed.TotalHours), _
                                          elapsed.Minutes, elapsed.Seconds)
        End If
       
    End Sub

    Private Sub BTN_Start_Click(sender As Object, e As EventArgs) Handles BTN_Start.Click
        If LBL_Mode.Text = "Stopwatch" Then
            If LBL_Time.Text = "00 : 00 : 00" = True Then
                MyTimeSpan = New TimeSpan(CInt(NUD_Hour.Value), _
                                          CInt(NUD_Min.Value), _
                                          CInt(NUD_Sec.Value))
                CountdownTimer.Enabled = True
                LBL_TotalTime.Text = MyTimeSpan.ToString
            Else
                CountdownTimer.Enabled = True
            End If
        ElseIf LBL_Mode.Text = "Countdown" Then
            CountdownTimer.Enabled = True
            MyStopWatch.Start()
        End If
    End Sub

    Private Sub BTN_Stop_Click(sender As Object, e As EventArgs) Handles BTN_Stop.Click
        If LBL_Mode.Text = "Stopwatch" Then
            CountdownTimer.Stop()
        ElseIf LBL_Mode.Text = "Countdown" Then
            MyStopWatch.Stop()
        End If
    End Sub

    Private Sub BTN_Reset_Click(sender As Object, e As EventArgs) Handles BTN_Reset.Click
        If LBL_Mode.Text = "Stopwatch" Then
            CountdownTimer.Enabled = False
            LBL_Time.Text = "00 : 00 : 00"
            LBL_TotalTime.Text = "00:00:00"
            MyTimeSpan = New TimeSpan(CInt(NUD_Hour.Value), _
                                      CInt(NUD_Min.Value), _
                                      CInt(NUD_Sec.Value))
        ElseIf LBL_Mode.Text = "Countdown" Then
            MyStopWatch.Reset()
            LBL_Time.Text = "00 : 00 : 00"
        End If
    End Sub

    Private Sub FrmMain_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        RemoveHandler Opacity1.Tick, AddressOf Opacity1_Tick
        RemoveHandler Opacity2.Tick, AddressOf Opacity2_Tick
        RemoveHandler CountdownTimer.Tick, AddressOf CountdownTimer_Tick
    End Sub

    Private Sub LBL_Mode_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LBL_Mode.LinkClicked
        If LBL_Mode.Text = "Stopwatch" Then
            LBL_Mode.Text = "Countdown"
            NUD_Hour.Enabled = False
            NUD_Min.Enabled = False
            NUD_Sec.Enabled = False
        ElseIf LBL_Mode.Text = "Countdown" Then
            LBL_Mode.Text = "Stopwatch"
            NUD_Hour.Enabled = True
            NUD_Min.Enabled = True
            NUD_Sec.Enabled = True
        End If
    End Sub

    Private Sub MiniTimer_ThemeContainer1_Click(sender As Object, e As EventArgs)

    End Sub
End Class
