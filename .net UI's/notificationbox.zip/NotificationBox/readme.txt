﻿The component has the following properties:

BorderCurve: An integer that decides the curve level of the borders. Minimum is "1".
---
Image: Adds a (16x16) image before the bold title.
---
NotificationType: "Enum", so you can switch between the type of boxes.
---
RoundCorners: Decides whether to use a Border Curve or not.
----
​ShowCloseButton: Decides whether to show a close button and make the box disposable or make it unremovable.

For any questions, please contact us, either by using the contact form on our website or email us directly on: HazelDev@outlook.com